public class Player {
    private String name;
    private int health;
    private int maxHP = 100;
    private int numPotions;

    public Player(String name) {
        this.name = name;
        this.health = 100;
        this.numPotions = 3;
        this.maxHP = 100;
    }

    public String getName() {
        return name;
    }

    public int getHealth() {
        return health;
    }

    public void checkPotion() {
    System.out.println("You have " + numPotions + " potions left.");
    }

    public void takePotion() {
        if(numPotions > 0) {
            System.err.println("You drink a potion and gain max health!");
            numPotions--;
            setHealth(maxHP);
        } else {
            System.out.println("You don't have any potions left!");
        }
    }

    private void setHealth(int points) {
        health += points;
        if(health > 100) {
            health = 100;
        }
    }

    public int getAttacked() {
        int randomDamage = (int) (Math.random() * 10) + 1;
        health -= randomDamage;
        return health;
    }
}