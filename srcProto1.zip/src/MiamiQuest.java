import java.util.Scanner;

public class MiamiQuest {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("************************\n*Welcome to MiamiQuest!*\n************************");
		System.out.print("Enter your name: ");
		String name = scanner.next();
		Player player = new Player(name);
		System.out.println("Welcome, " + player.getName());
		System.out.println("UH OH, A BIG MONSTER APPEARS!");
		Monster monster = new Monster("Big Monster", 100, 10);
		System.out.println("It slices at you! You take " + player.getAttacked() + " damage!");
		player.checkPotion();
		System.out.println("Your health is: " + player.getHealth());
		player.takePotion();
		System.err.println(player.getHealth());
		player.takePotion();
		player.takePotion();
	}
}
