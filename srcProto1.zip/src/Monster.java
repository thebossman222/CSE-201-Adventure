public class Monster {
    
    private String name;
    private int health;
    private int xp;
    private boolean isAlive = true;

    public Monster(String name, int health, int damage) {
        this.name = name;
        this.health = health;
    }

    
    public String getName() {
        return name;
    }

    public int getHealth() {
        return health;
    }

    public String toString() {
        return name + " has " + health + " health.";
    }
}
